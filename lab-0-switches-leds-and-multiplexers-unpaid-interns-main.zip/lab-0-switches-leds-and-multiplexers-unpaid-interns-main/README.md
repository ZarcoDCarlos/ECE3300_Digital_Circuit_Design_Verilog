# Lab 0 - Switches, Leds and Multiplexers
## Unpaid Interns: Carlos Zarco and Rafael Hernandez
### Due: 2/1/2023

<ins>Description:</ins>

For this lab, we started with a 1-bit 2x1 Multiplexer.
Through **instantiation**, we used that simple 2x1 MUX to create a 3-bit 2x1 Multiplexer.
Using three instantiations of the 3-bit 2x1 MUX, we were able to create a 3-bit 4-1 MUX.
By instantiating the simple 2x1 MUX, we were able to create more complex circuits.
We utilized **I/O** devices to implement our Multiplexers by assigning inputs to switches and outputs to LEDs.
