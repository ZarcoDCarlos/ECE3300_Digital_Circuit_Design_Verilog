# lab-8-parking-lot-occupancy-counter-unpaid-interns
lab-8-parking-lot-occupancy-counter-unpaid-interns created by GitHub Classroom
## Unpaid Interns: Carlos Zarco and Rafael Hernandez
### Due: 4/5/2023

<ins> Parking lot occupancy counter (FSMs)</ins>
Dual Sequence Detector: This is a Mealy FSM with a inputs a, b, reset_n and clk. There are also outputs car_enter, and car_exit. 
Sensor A is a sensor for the left side to detect a car when it is just entering, and sensor B is for the right side to detect when a car is just starting to leave.
A car must trigger both sensors to leave or enter. When a car is entering, the counter is incremented by 1 on the FSM. When a car is leaving, the count is decremented by 1
Note: The counter is an 8-bit up-down-load counter, so the maximum value is 255. There is a reset button used to reset the count that is displayed on the sseg display. 

The FSM detects the following sequence for entering:
     A B
  1. 0 0
  2. 1 0
  3. 1 1 // Car on both sensors
  4. 0 1 
  5. 0 0
  
The FSM detects the following sequence for exiting:
     A B
  1. 0 0 
  2. 0 1
  3. 1 1 // Car on both sensors
  4. 1 0
  5. 0 0
  
Any other sequence is invalid and will not affect the count.
  
 
Lab 8: Parking Lot Counter FSM
![Lab 8 FSM Diagram](https://github.com/Spring-2023-Classes/lab-8-parking-lot-occupancy-counter-unpaid-interns/blob/main/Lab8_Parking_Lot_FSM.jpg)

