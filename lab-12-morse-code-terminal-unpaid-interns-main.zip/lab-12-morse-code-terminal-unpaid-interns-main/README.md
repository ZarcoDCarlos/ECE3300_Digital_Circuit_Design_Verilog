# lab-12-morse-code-terminal-unpaid-interns
lab-12-morse-code-terminal-unpaid-interns created by GitHub Classroom
## Unpaid Interns: Carlos Zarco and Rafael Hernandez
### Due: 5/3/2023

<ins> Morse Code Terminal</ins>

For this lab, we will change the circuit we have created in lab 11 so that we will be able to display the ASCII characters we input into our FPGA boards onto our computer. The change we made to allow us to display the ASCII characters onto our computers is our change from using a FIFO module to using a UART module. This module allows us to output a bit stream from our USB cable into our computers. To help us see the outputs that the FPGA board has sent to our computers, we used a application that will allow us to open a terminal which will monitor the inputs that we get from our FPGA board from the port where the computer is connected to it. Besides this change from our previous code, this was the only major change we made onto our code since our last lab.

Lab 12: Morse Decoder FSM ![Lab 12: Morse Decoder FSM](https://github.com/Spring-2023-Classes/lab-12-morse-code-terminal-unpaid-interns/blob/b628305850c09db18db8231014e36a427c051bc9/Lab12_fsm.jpg)
