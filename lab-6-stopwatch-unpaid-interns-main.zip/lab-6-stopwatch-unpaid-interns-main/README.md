# lab-6-stopwatch-unpaid-interns
lab-6-stopwatch-unpaid-interns created by GitHub Classroom
## Unpaid Interns: Carlos Zarco and Rafael Hernandez
### Due: 3/15/2023

<ins>Building a Stopwatch</ins>
The stopwatch we designed has the following specifications:
 - Display time shoule be formatted as MM.SS.FF (Minutes, Seconds, Hundredth of a Second).
    - MM:00->59 (minutes)
    - SS:00->59 (seconds)
    - FF:00->99 (hundredth of a second)
  - The middle pushbutton is used as a start/pause/continue.
  - The CPU Reset pin is used to reset the stopwatch.

To implement the start/pause/continue functionality, we used a T-FF to toggle between 0 and 1.

The stopwatch has two timers, one drives seconds and the other drives the hundredths of a second. They actually operate independently of each other. I calculated the final value necessary for the timer to last 1 hundredth of a second, and 1 second. For the FF timer, the final value is 999,999. For the SS timer, the final value is 99,999,999. I connected these timers to two separate counters, one counts from 0-99 for hundredths of a second and the other counts from 0-59 for seconds. A third counter from 0-59 is used for minutes. 

However, I could not use a third timer for minutes since the final value I calculated was out of range for the timer. To fix this, we decided to use an always statement with an if statement inside. The if statement checks if both timers are done, and also checks to see if the seconds counter has reached its final value, 59. If this is all true, then the enable for the minutes counter is set to one. The minutes counter counts from 00 to 59. We used three binary to BCD converters to convert the count for minutes, seconds, and hundredths of a second to BCD form. Next, we used our sseg driver to output the results on 6 sseg displays on the FPGA. 

Lab 6 Rough Schematic:
We drew a rough schematic which is included below however, we changed our implementation of the project as we coded. To account for this I also included the schematic that Vivado generated as well. 
![Lab 6 Rough Schematic](https://github.com/Spring-2023-Classes/lab-6-stopwatch-unpaid-interns/blob/main/Lab%206/lab_6_rough_schematic.jpg)

Lab 6 Vivado Schematic:
![Lab 6 Vivado Schematic](https://github.com/Spring-2023-Classes/lab-6-stopwatch-unpaid-interns/blob/main/Lab%206/vivado_schematic_lab_6.png)

